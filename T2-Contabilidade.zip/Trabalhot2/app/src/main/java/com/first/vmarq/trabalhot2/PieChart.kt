package com.first.vmarq.trabalhot2

import android.net.wifi.WifiConfiguration.AuthAlgorithm.strings
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.Parcelable
import android.util.EventLogTags
import com.github.mikephil.charting.charts.PieChart
import com.github.mikephil.charting.components.Description
import com.github.mikephil.charting.data.PieData
import com.github.mikephil.charting.data.PieDataSet
import com.github.mikephil.charting.data.PieEntry
import com.github.mikephil.charting.utils.ColorTemplate
import kotlinx.android.synthetic.main.activity_pie_chart.view.*
import java.lang.NumberFormatException
import java.util.ArrayList

class PieChart : AppCompatActivity() {

    private val TAG = "PieChart"



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pie_chart)

        //Declaracao;
        var intent = intent
        //Conversao de array de string para float em lsValue, caso contrário, não entra no ChartPie
        val lsGroup = intent.getStringArrayListExtra("Group")
        val lsValueSt = intent.getStringArrayListExtra("Value")
        val lsValue = lsValueSt.map { it.toFloat() }
        //Inserção dos dados em pieEntries
        val pieEntries = ArrayList<PieEntry>()
        //Inserção dos dados no Pie
        for (i in lsGroup.indices) {
            pieEntries.add(PieEntry(lsValue[i],lsGroup[i]))
        }

        val dataSet = PieDataSet(pieEntries, "Gastos dos dados por seção")
        dataSet.setColors(*ColorTemplate.COLORFUL_COLORS)
        val data = PieData(dataSet)
        val idPieChart = findViewById(R.id.idPieChart) as PieChart
        idPieChart.data = data
        idPieChart.invalidate()

    }

}