package com.first.vmarq.trabalhot2

import android.app.ProgressDialog
import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.Parcelable
import android.widget.*
import com.github.mikephil.charting.data.PieEntry
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import kotlinx.android.synthetic.main.activity_main.*
import java.util.ArrayList

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        initialise()

        val lsGroup = ArrayList<String>()
        val lsValue = ArrayList<String>()

        //Cria um adapter;
        val adapter = ArrayAdapter<String>(this, android.R.layout.simple_list_item_1)
        //Liga o adapter ao ListView;
        lsView!!.adapter = adapter //Trocar ID do listView para listView;

        //Configura o evento de adicionar na lista;
        btnAdd!!.setOnClickListener {
            //Se algum dos edits estiverem vazio, pedir novamente;
            if (etGroup!!.text.isEmpty() || etValue!!.text.isEmpty()) {
                Toast.makeText(this, "Favor preencha com algo que está faltando", Toast.LENGTH_SHORT).show()
            } else {
                //Armazena o produto e a quantidade do editText em variáveis;
                val valor = etValue?.text.toString()
                val grupo = etGroup?.text.toString()

                //Somando para passar os valores para o chart
                lsGroup.add(grupo)
                lsValue.add(valor)

                //Transfere as variavies concatenadas para a lista;
                adapter.add(grupo + ": " + valor)

                //Limpar caixas de texto
                etGroup!!.text.clear()
                etValue!!.text.clear()
            }
        }

        //Configura o evento de long click;
        lsView!!.setOnItemLongClickListener { parent, view, position, id ->
            val item = adapter.getItem(position)
            adapter.remove(item)
            true
        }

        btn_chart!!.setOnClickListener {envgraph(lsGroup,lsValue)}

    }

    private val TAG = "MainActivity"

    //UI elementos
    private var etGroup: EditText? = null
    private var etValue: EditText? = null
    private var btnAdd: Button? = null
    private var lsView: ListView? = null
    private var btn_chart: Button? = null

    //Firebase
    private var mDatabaseReference: DatabaseReference? = null
    private var mDatabase: FirebaseDatabase? = null
    private var mAuth: FirebaseAuth? = null

    private fun initialise() {
        etValue = findViewById(R.id.et_value) as EditText
        etGroup = findViewById(R.id.et_group) as EditText
        btnAdd = findViewById(R.id.btn_add) as android.widget.Button
        lsView = findViewById(R.id.ls_view) as android.widget.ListView
        btn_chart = findViewById(R.id.btn_chart) as Button
        mDatabase = FirebaseDatabase.getInstance()
        mDatabaseReference = mDatabase!!.reference!!.child("Users")
        mAuth = FirebaseAuth.getInstance()

    }

    private fun envgraph(lsGroup:ArrayList<String>,lsValue:ArrayList<String>) {
        //Passar os valores via intent para a página de chart
        val intent = Intent(this@MainActivity, PieChart::class.java)
        intent.putStringArrayListExtra("Group", lsGroup)
        intent.putStringArrayListExtra("Value", lsValue)
        startActivity(intent)
    }

}

